"""
Request models — Pydantic validates every incoming API payload against these.
If a required field is missing or the wrong type, FastAPI returns a clear 422 error
before your logic even runs.
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Literal


# ── Shared sub-models ─────────────────────────────────────────────

class SubjectStrengths(BaseModel):
    math:          int = Field(ge=1, le=5, description="1=very weak, 5=very strong")
    biology:       int = Field(ge=1, le=5)
    physics:       int = Field(ge=1, le=5)
    chemistry:     int = Field(ge=1, le=5)
    communication: int = Field(ge=1, le=5)
    reasoning:     int = Field(ge=1, le=5)
    creativity:    int = Field(ge=1, le=5)


# ── Main student profile payload ──────────────────────────────────

class StudentProfileRequest(BaseModel):
    classLevel: Literal["8","9","10","11","12","college_1","college_2","college_3"]
    stream:     Literal["PCM","PCB","Commerce","Arts","None","Unknown"]
    state:      str

    subjectStrengths:      SubjectStrengths
    favoriteSubjects:      List[str] = []
    leastFavoriteSubjects: List[str] = []

    # Tags like ["coding", "healthcare", "design", "public_service"]
    interestTags: List[str] = []

    # Tags like ["analytical", "structured", "creative"]
    workStyle: List[str] = []

    careerGoal:               Literal["stable","high_growth","flexible","unsure"] = "unsure"
    studyDurationWillingness: Literal["short","medium","long"] = "medium"
    sectorPreference:         Literal["public","private","either"] = "either"
    incomeVsPassion:          Literal["income","passion","balance"] = "balance"

    # Optional profile fields — stored in Firestore but not used in scoring
    age:    Optional[int] = None
    gender: Optional[str] = None
    board:  Optional[str] = None

    clarityLevel:    Literal["clear","some_idea","confused","no_interest"]
    regretFlag:      bool = False
    targetDirection: Optional[Literal[
        "medical","engineering","commerce","design","law","public_service","unsure"
    ]] = None

    class Config:
        # Allow extra fields to be ignored rather than causing an error
        extra = "ignore"


# ── Eligibility request ───────────────────────────────────────────

class EligibilityRequest(BaseModel):
    profile:    StudentProfileRequest
    careerIds:  List[str] = Field(description="Career IDs to check eligibility for")


# ── Stream switch request ─────────────────────────────────────────

class StreamSwitchRequest(BaseModel):
    profile:     StudentProfileRequest
    topCareerIds: List[str] = []


# ── Roadmap request ───────────────────────────────────────────────

class RoadmapRequest(BaseModel):
    profile:          StudentProfileRequest
    selectedCareerId: str
    timeframe:        Literal[7, 30, 90] = 30
