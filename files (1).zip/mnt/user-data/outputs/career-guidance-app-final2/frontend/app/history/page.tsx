"use client";
// app/history/page.tsx — shows all past recommendation sessions
import { useEffect, useState } from "react";
import Link from "next/link";
import ProtectedRoute from "@/components/shared/ProtectedRoute";
import Navbar from "@/components/shared/Navbar";
import { useAuth } from "@/context/AuthContext";
import { getRecommendationHistory } from "@/lib/firestore";
import type { RecommendationHistory } from "@/types";

// Formats ISO string → "12 Jun 2024, 4:30 PM"
function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleString("en-IN", {
      day:    "numeric",
      month:  "short",
      year:   "numeric",
      hour:   "2-digit",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}

function HistoryCard({ record }: { record: RecommendationHistory }) {
  const topThree = record.topCareers.slice(0, 3);
  const modeLabel = record.mode === "exploration" ? "🧭 Exploration" : "🎯 Best-fit";
  const modeColor = record.mode === "exploration"
    ? "bg-purple-50 text-purple-700 border-purple-200"
    : "bg-green-50 text-green-700 border-green-200";

  return (
    <div className="card space-y-4">
      {/* Header row */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs text-gray-400">{formatDate(record.generatedAt)}</p>
          <span className={`inline-block mt-1 text-xs font-medium px-2.5 py-0.5 rounded-full border ${modeColor}`}>
            {modeLabel}
          </span>
        </div>
        {record.streamSwitchPathways?.length > 0 && (
          <span className="text-xs bg-amber-50 text-amber-700 border border-amber-200 px-2.5 py-0.5 rounded-full font-medium flex-shrink-0">
            🔄 Switch pathways included
          </span>
        )}
      </div>

      {/* Top careers */}
      {topThree.length > 0 ? (
        <div className="space-y-2">
          {topThree.map((career, i) => (
            <div key={career.careerId} className="flex items-center gap-3">
              {/* Rank */}
              <span className="w-6 h-6 rounded-full bg-gray-100 text-gray-500 text-xs font-bold flex items-center justify-center flex-shrink-0">
                {i + 1}
              </span>
              {/* Career name */}
              <span className="text-sm font-medium text-gray-800 flex-1 truncate">
                {career.name}
              </span>
              {/* Score bar */}
              <div className="flex items-center gap-1.5 flex-shrink-0">
                <div className="w-16 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary-400 rounded-full"
                    style={{ width: `${career.score}%` }}
                  />
                </div>
                <span className="text-xs text-gray-400 w-7 text-right">{career.score}%</span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-sm text-gray-400 italic">No career data saved for this session.</p>
      )}

      {/* Reload this session */}
      <button
        onClick={() => {
          sessionStorage.setItem("latestRecommendation", JSON.stringify({
            mode:                 record.mode,
            topCareers:           record.topCareers,
            alternatives:         record.alternatives,
            streamSwitchPathways: record.streamSwitchPathways,
            resources:            record.resources,
            generatedAt:          record.generatedAt,
          }));
          window.location.href = "/results";
        }}
        className="btn-secondary text-sm w-full text-center"
      >
        View full results →
      </button>
    </div>
  );
}

export default function HistoryPage() {
  const { user } = useAuth();
  const [history, setHistory] = useState<RecommendationHistory[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);

  useEffect(() => {
    if (!user) return;
    getRecommendationHistory(user.uid)
      .then(setHistory)
      .catch((err) => {
        console.error("[history] Failed to load:", err);
        setLoadError(true);
      })
      .finally(() => setLoading(false));
  }, [user]);

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-3xl mx-auto px-4 py-10 space-y-6">

          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Recommendation history</h1>
              <p className="text-gray-500 text-sm mt-1">
                All your past career recommendation sessions, newest first.
              </p>
            </div>
            <Link href="/onboarding" className="btn-primary text-sm flex-shrink-0">
              New session →
            </Link>
          </div>

          {loading && (
            <div className="flex items-center justify-center py-20">
              <div className="w-8 h-8 border-4 border-primary-400 border-t-transparent rounded-full animate-spin" />
            </div>
          )}

          {!loading && loadError && (
            <div className="card text-center py-10 space-y-2">
              <p className="text-2xl">⚠️</p>
              <p className="text-gray-600 font-medium">Could not load your history</p>
              <p className="text-gray-400 text-sm">
                Check your internet connection or{" "}
                <button
                  onClick={() => window.location.reload()}
                  className="text-primary-600 underline"
                >
                  try again
                </button>
                .
              </p>
            </div>
          )}

          {!loading && !loadError && history.length === 0 && (
            <div className="card text-center py-12 space-y-3">
              <p className="text-4xl">📋</p>
              <p className="text-gray-600 font-medium">No history yet</p>
              <p className="text-gray-400 text-sm">
                Complete your profile to generate your first recommendations.
              </p>
              <Link href="/onboarding" className="btn-primary text-sm inline-block mt-2">
                Get started →
              </Link>
            </div>
          )}

          {!loading && history.length > 0 && (
            <div className="space-y-4">
              {history.map((record) => (
                <HistoryCard key={record.id} record={record} />
              ))}
            </div>
          )}

          {/* Firestore note */}
          {!loading && history.length > 0 && (
            <p className="text-center text-xs text-gray-400">
              {history.length} session{history.length !== 1 ? "s" : ""} saved ·
              History is stored securely in your account only
            </p>
          )}
        </div>
      </div>
    </ProtectedRoute>
  );
}
